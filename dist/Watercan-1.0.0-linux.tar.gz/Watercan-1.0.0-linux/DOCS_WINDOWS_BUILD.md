# Building a single Windows x86_64 executable on Linux

This document explains how to build a self-contained Windows `Watercan.exe` from Linux using MinGW-w64. It assumes you want a single standalone exe with an embedded About image (`TheBrokenMind.png`). The large sample JSON (`seasonal_spiritshop.json`) is intentionally **not** embedded and should be distributed alongside the exe (it is **not** copied to the build directory during configure).

## Prerequisites

- Install MinGW-w64 cross toolchain (x86_64) and utilities:
  - Debian/Ubuntu:
    sudo apt update && sudo apt install mingw-w64 build-essential cmake xxd

- Ensure xxd is installed (usually provided by `vim-common` on Debian/Ubuntu).

## Build steps (recommended)

1. Configure with the MinGW toolchain and enable single-exe embedding:

```bash
mkdir -p build-windows && cd build-windows
cmake -DCMAKE_TOOLCHAIN_FILE=../cmake/mingw-x86_64-toolchain.cmake \
      -DBUILD_WINDOWS_SINGLE_EXE=ON \
      -DCMAKE_BUILD_TYPE=Release ..
```

2. Build:

```bash
cmake --build . --config Release -- -j$(nproc)
```

3. The produced `Watercan.exe` will be in the build directory. You can inspect it with `file Watercan.exe`.

## Notes and troubleshooting

- If `xxd` is missing, CMake will abort with a helpful error; install `xxd` or disable embedding.
- Static linking results in a large exe but reduces runtime external dependencies.
- Running the GUI under Wine for verification is an easy smoke test:

```bash
wine ./Watercan.exe
```

- If the binary fails to start, prefer testing on a Windows VM to confirm graphical behavior.

## What this produces

- A single `Watercan.exe` that has the About image embedded (if `BUILD_WINDOWS_SINGLE_EXE=ON`). Sample JSON files (e.g., `seasonal_spiritshop.json`) are **not** embedded and must be provided at runtime (place them in the same directory as the executable or open them from within the app).
